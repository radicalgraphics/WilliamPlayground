<?php
/**
* @package   Radiance
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// no direct access
die('Restricted access');

?>

Changelog
------------

1.0.4
# Fixed wrapper width and breaking sidebar

1.0.3
^ Updated menu icons and titles according to Warp 6.2

1.0.2
+ Fixed error when Firefly effect is disabled within styles

1.0.1
+ Fixed error when Firefly effect is disabled

1.0.0
+ Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note