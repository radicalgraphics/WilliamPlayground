<div class="module <?php echo $style; ?>">

	<?php echo $badge; ?>
	
	<div class="box-t">
		<div></div>
	</div>
	
	<div class="box-m deepest">
	
		<?php if ($showtitle) echo $title; ?>
		<?php echo $content; ?>
		
	</div>

</div>