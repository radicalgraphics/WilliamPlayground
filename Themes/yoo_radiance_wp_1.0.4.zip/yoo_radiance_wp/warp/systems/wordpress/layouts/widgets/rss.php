<?php echo $module->content; ?>

<p>
    <a class="button-default" href="<?php echo $module->params['url']; ?>" target="_blank"><?php _e('Read feed'); ?></a>
</p>