<?php
/*
Widget Name: Tabs Widget
Description: Displays a block of tabs .
Version: trunk
Author: Sunil chaulagain
Author URI: http://tuchuk.com
*/
return new SiteOrigin_Widgets_Loader( 'tabs', __FILE__, plugin_dir_path(__FILE__).'inc/tabs-widget.php' );