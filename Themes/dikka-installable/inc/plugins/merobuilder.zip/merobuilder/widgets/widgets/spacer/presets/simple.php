<?php

return array(

	'blank' => array(
		'border' => '0px',
	),

	'lightline_thin' => array(
		'border' => '1px',
		'color' => '#ddd',

	),

	'lightline_normal' => array(
		'border' => '2px',
		'color' => '#ddd',

	),

	'lightline_thick' => array(
		'border' => '4px',
		'color' => '#ddd',

	),

	'darkline_thin' => array(
		'border' => '1px',
		'color' => '#555',
	),

	'darkline_normal' => array(
		'border' => '2px',
		'color' => '#555',

	),

	'darkline_thick' => array(
		'border' => '4px',
		'color' => '#555',

	),

	

);
