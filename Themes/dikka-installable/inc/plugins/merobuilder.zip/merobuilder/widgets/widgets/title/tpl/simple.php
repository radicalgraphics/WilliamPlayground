<h<?php  echo $instance['size'];?>  class="align-<?php echo $instance['align'] ?>">
	<?php echo $instance['heading'] ?>
</h<?php  echo $instance['size'];?>>
<?php if(!empty($instance['line']))  { ?>
<div class="divider colored"></div>
<?php } ?>
