<?php

class SiteOrigin_Panels_Widget_Postloop extends SiteOrigin_Panels_Widget  {
	function __construct() {
		parent::__construct(
			__('Post Loop (Builder)', 'siteorigin-panels'),
			array(
				'description' => __('Displays the recent/random/popular posts. ', 'siteorigin-panels'),
				'default_style' => 'default',
			),
			array(),
			array(

				'type' => array(
					'type' => 'select',
					'label' => __('Posts to display', 'siteorigin-panels'),
					'options' => array(
						'rand' => __('Random Posts', 'siteorigin-panels'),
						'date' => __('Latest Posts', 'siteorigin-panels'),	
						'comment_count' => __('Popular Posts', 'siteorigin-panels'),
					)
				),
			)
		);
	}

	
}