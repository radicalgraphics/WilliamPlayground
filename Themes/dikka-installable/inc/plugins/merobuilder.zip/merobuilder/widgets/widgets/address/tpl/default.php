<?php if ( !empty( $instance['title'] ) ) {
	echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title'];
} ?>
<div class="address">
<?php if(!empty($instance['address'])): ?>
<p><i class="fa fa-map-marker"></i> <b>Adress : </b><?php echo esc_html($instance['address']);?> </p>
<?php endif; ?>
<?php if(!empty($instance['phone'])): ?>
<p><i class="fa fa-phone"></i> <b>Phone : </b><?php echo esc_html($instance['phone']);?> </p>
<?php endif; ?>
<?php if(!empty($instance['fax'])): ?>
<p><i class="fa fa-print"></i> <b>Fax : </b><?php echo esc_html($instance['fax']);?> </p>
<?php endif; ?>
<?php if(!empty($instance['email'])): ?>
<p><i class="fa fa-envelope"></i> <b>Email : </b>
	<a href="mailto:<?php echo esc_html($instance['email']);?>">
		<?php echo esc_html($instance['email']);?> 
	</a>
	</p>
<?php endif; ?>
<?php if(!empty($instance['website'])): ?>
<p><i class="fa fa-globe"></i> <b>Website:</b>
	<a href="<?php echo esc_url($instance['website']);?>">
	<?php echo esc_url($instance['website']);?> 
	</a>
</p>

<?php endif; ?>
</div>