<?php get_header(); ?>

	<section class="page-content the-content group">

		<h1 class="item-title">
			<?php _e('404 Page Not Found', 'onioneye'); ?>
		</h1>
			
		<p><?php _e('Apologies, but the page you requested could not be found. Perhaps searching will help.', 'onioneye'); ?></p>
	
	</section><!-- /.page-content -->

<?php get_footer(); ?>