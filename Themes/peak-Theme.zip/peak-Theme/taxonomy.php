<?php get_header(); ?>
	
	<?php get_template_part('includes/portfolio'); ?>			    			
	
<?php get_footer(); ?>
